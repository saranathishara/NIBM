#import socket
from socket import*

HOST = ""   #Host - Localhost or IP- 192.168.1.1
PORT = 8000
s = socket(AF_INET , SOCK_STREAM)
s.bind((HOST,PORT))
s.listen(1)
conn, addr = s.accept()
print("Connected by", addr)
while True:
    data = conn.recv(1024) #Receive Data
    print("Received :", repr(data)) #Print Data ( Message) the User Sent
    reply = raw_input("Reply :")
    conn.sendall(reply)

    conn.close()
